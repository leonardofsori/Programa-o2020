INSERT INTO `books` (
	`book_id`,
	`book_isbn`,
	`book_title`,
	`book_author`,
	`book_category`
) VALUES
(1, 7893, 'Laravel Tiger', 'Mutafaf', 'Programming'),
(2, 8934, 'Android Programming', 'Farrukh', 'Programming'),
(3, 8902, 'Intro to Psychology', 'Ayesha', 'Psychology'),
(4, 2345, 'Calculus-1', 'John Doe', 'Math'),
(5, 8927, 'Chemistry Part-1', 'Aliza Mam', 'Chemistry'),
(6, 6723, 'Math Part-1', 'Sir Sohail Amanat', 'Math'),
(7, 7896, 'Javascript for begginners', 'Shami ', 'Programming'),
(8, 8978, 'iOS App ', 'Ehtesham Mehmood', 'Mobile Programming'),
(9, 8987, 'Physics', 'Sir Waqas', 'Physics'),
(10, 7890, 'HTML for dummies', 'Ehtesham Shami', 'Programming'),
(11, 1234, 'CodeIgniter Framework Introduction', 'Mutafaf', 'Programming');
