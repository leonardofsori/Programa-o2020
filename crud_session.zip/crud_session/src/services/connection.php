<?php

$databaseHost = 'localhost';
$databaseName = 'teste_db';
$databaseUsername = 'root';
$databasePassword = 'root';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
